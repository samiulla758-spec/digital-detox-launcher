import {
  MessageCircle, Wallet, CreditCard, Banknote, Phone, MessagesSquare, Sparkles,
  Instagram, Youtube, Facebook, Twitter, Music, Camera, Send, Globe, Film,
  Mail, Map, MessageSquare, type LucideIcon,
} from 'lucide-react-native';

const MAP: Record<string, LucideIcon> = {
  MessageCircle, Wallet, CreditCard, Banknote, Phone, MessagesSquare, Sparkles,
  Instagram, Youtube, Facebook, Twitter, Music, Camera, Send, Globe, Film,
  Mail, Map, MessageSquare,
};

export function getIcon(name: string): LucideIcon {
  return MAP[name] ?? MessageCircle;
}
