export type AppCategory = 'allowed' | 'restricted';

export interface AppInfo {
  key: string;
  name: string;
  category: AppCategory;
  color: string;
  icon: string; // lucide icon name
  subtitle: string;
}

// Default allowed apps (unlimited access).
export const DEFAULT_ALLOWED_KEYS = [
  'whatsapp',
  'phonepe',
  'gpay',
  'paytm',
  'phone',
  'messages',
  'gemini',
];

// Full catalog of apps shown on the launcher.
// Color is used for the app icon tile background gradient accent.
export const APP_CATALOG: AppInfo[] = [
  { key: 'whatsapp', name: 'WhatsApp', category: 'allowed', color: '#25D366', icon: 'MessageCircle', subtitle: 'Messaging' },
  { key: 'phonepe', name: 'PhonePe', category: 'allowed', color: '#5F259F', icon: 'Wallet', subtitle: 'Payments' },
  { key: 'gpay', name: 'Google Pay', category: 'allowed', color: '#1A73E8', icon: 'CreditCard', subtitle: 'Payments' },
  { key: 'paytm', name: 'Paytm', category: 'allowed', color: '#00BAF2', icon: 'Banknote', subtitle: 'Payments' },
  { key: 'phone', name: 'Phone', category: 'allowed', color: '#34C759', icon: 'Phone', subtitle: 'Calls' },
  { key: 'messages', name: 'Messages', category: 'allowed', color: '#34A4E4', icon: 'MessagesSquare', subtitle: 'SMS' },
  { key: 'gemini', name: 'Gemini', category: 'allowed', color: '#4285F4', icon: 'Sparkles', subtitle: 'AI Assistant' },
  { key: 'instagram', name: 'Instagram', category: 'restricted', color: '#E1306C', icon: 'Instagram', subtitle: 'Social' },
  { key: 'youtube', name: 'YouTube', category: 'restricted', color: '#FF0000', icon: 'Youtube', subtitle: 'Video' },
  { key: 'facebook', name: 'Facebook', category: 'restricted', color: '#1877F2', icon: 'Facebook', subtitle: 'Social' },
  { key: 'x', name: 'X', category: 'restricted', color: '#111111', icon: 'Twitter', subtitle: 'Social' },
  { key: 'tiktok', name: 'TikTok', category: 'restricted', color: '#010101', icon: 'Music', subtitle: 'Video' },
  { key: 'snapchat', name: 'Snapchat', category: 'restricted', color: '#FFFC00', icon: 'Camera', subtitle: 'Social' },
  { key: 'telegram', name: 'Telegram', category: 'restricted', color: '#26A5E4', icon: 'Send', subtitle: 'Messaging' },
  { key: 'chrome', name: 'Chrome', category: 'restricted', color: '#4285F4', icon: 'Globe', subtitle: 'Browser' },
  { key: 'netflix', name: 'Netflix', category: 'restricted', color: '#E50914', icon: 'Film', subtitle: 'Streaming' },
  { key: 'spotify', name: 'Spotify', category: 'restricted', color: '#1DB954', icon: 'Music', subtitle: 'Music' },
  { key: 'reddit', name: 'Reddit', category: 'restricted', color: '#FF4500', icon: 'MessageSquare', subtitle: 'Forum' },
  { key: 'gmail', name: 'Gmail', category: 'restricted', color: '#EA4335', icon: 'Mail', subtitle: 'Email' },
  { key: 'maps', name: 'Maps', category: 'restricted', color: '#34A853', icon: 'Map', subtitle: 'Navigation' },
];

export function getCatalogByKey(key: string): AppInfo | undefined {
  return APP_CATALOG.find((a) => a.key === key);
}

// Resolve an app's effective category given the current allowed-keys set.
export function effectiveCategory(app: AppInfo, allowedKeys: string[]): AppCategory {
  if (allowedKeys.includes(app.key)) return 'allowed';
  return 'restricted';
}
