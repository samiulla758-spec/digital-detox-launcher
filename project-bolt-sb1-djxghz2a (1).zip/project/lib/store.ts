import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase } from './supabase';
import type { DetoxConfig, DetoxDailyUsage, DetoxSession } from './types';
import { getCatalogByKey, effectiveCategory } from './apps';

export function todayKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function formatHMS(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export interface ActiveSession {
  appKey: string;
  appName: string;
  restricted: boolean;
  startedAt: number; // epoch ms
}

export interface DetoxStore {
  config: DetoxConfig | null;
  loading: boolean;
  error: string | null;
  usedSeconds: number; // restricted usage for today
  activeSession: ActiveSession | null;
  pinned: boolean; // whether PIN has been verified this session
  // actions
  refresh: () => Promise<void>;
  openApp: (appKey: string) => Promise<{ locked: boolean }>;
  closeActiveApp: () => Promise<void>;
  verifyPin: (pin: string) => Promise<boolean>;
  updatePin: (newPin: string) => Promise<void>;
  updateDailyLimit: (seconds: number) => Promise<void>;
  updateAllowedApps: (keys: string[]) => Promise<void>;
  resetUsage: () => Promise<void>;
}

export function useDetoxStore(): DetoxStore {
  const [config, setConfig] = useState<DetoxConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usedSeconds, setUsedSeconds] = useState(0);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [pinned, setPinned] = useState(false);

  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const activeRef = useRef<ActiveSession | null>(null);
  activeRef.current = activeSession;

  const refresh = useCallback(async () => {
    setError(null);
    try {
      const [{ data: cfg, error: cfgErr }, { data: usage, error: usageErr }] = await Promise.all([
        supabase.from('detox_config').select('*').eq('id', 1).maybeSingle(),
        supabase.from('detox_daily_usage').select('*').eq('date', todayKey()).maybeSingle(),
      ]);
      if (cfgErr) throw cfgErr;
      if (usageErr) throw usageErr;
      setConfig(cfg as DetoxConfig | null);
      setUsedSeconds(usage ? (usage as DetoxDailyUsage).used_seconds : 0);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Failed to load';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Midnight reset check: every 30s, see if the date rolled over.
  useEffect(() => {
    let lastDate = todayKey();
    const iv = setInterval(() => {
      const now = todayKey();
      if (now !== lastDate) {
        lastDate = now;
        setUsedSeconds(0);
        // If the active app is restricted, it now has fresh budget.
      }
    }, 30000);
    return () => clearInterval(iv);
  }, []);

  // Persist the accumulated usage of the active restricted session on tick.
  useEffect(() => {
    if (!activeSession) {
      if (tickRef.current) {
        clearInterval(tickRef.current);
        tickRef.current = null;
      }
      return;
    }
    if (tickRef.current) clearInterval(tickRef.current);
    tickRef.current = setInterval(async () => {
      const cur = activeRef.current;
      if (!cur || !cur.restricted) return;
      const elapsed = Math.floor((Date.now() - cur.startedAt) / 1000);
      if (elapsed <= 0) return;
      const newUsed = usedSeconds + elapsed;
      // Upsert daily usage.
      const { error } = await supabase
        .from('detox_daily_usage')
        .upsert(
          { date: todayKey(), used_seconds: newUsed, updated_at: new Date().toISOString() },
          { onConflict: 'date' },
        );
      if (!error) {
        setUsedSeconds(newUsed);
        // Reset the startedAt so the next tick counts from now.
        setActiveSession({ ...cur, startedAt: Date.now() });
        // Check limit — auto-lock.
        const limit = config?.daily_limit_seconds ?? 10800;
        if (newUsed >= limit) {
          // Force-close the restricted app.
          await closeActiveAppInternal(cur, elapsed);
        }
      }
    }, 5000);
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
      tickRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeSession, usedSeconds, config]);

  async function closeActiveAppInternal(cur: ActiveSession, elapsed: number) {
    try {
      await supabase.from('detox_sessions').insert({
        app_key: cur.appKey,
        app_name: cur.appName,
        restricted: cur.restricted,
        date: todayKey(),
        duration_seconds: elapsed,
        started_at: new Date(cur.startedAt).toISOString(),
        ended_at: new Date().toISOString(),
      });
    } catch {
      // best-effort log
    }
    setActiveSession(null);
  }

  const closeActiveApp = useCallback(async () => {
    const cur = activeRef.current;
    if (!cur) return;
    const elapsed = Math.max(1, Math.floor((Date.now() - cur.startedAt) / 1000));
    if (cur.restricted) {
      const newUsed = usedSeconds + elapsed;
      await supabase
        .from('detox_daily_usage')
        .upsert(
          { date: todayKey(), used_seconds: newUsed, updated_at: new Date().toISOString() },
          { onConflict: 'date' },
        )
        .then(({ error }) => {
          if (!error) setUsedSeconds(newUsed);
        });
    }
    await closeActiveAppInternal(cur, elapsed);
  }, [usedSeconds]);

  const openApp = useCallback(
    async (appKey: string): Promise<{ locked: boolean }> => {
      const app = getCatalogByKey(appKey);
      if (!app) return { locked: true };
      const allowedKeys = config?.allowed_apps ?? [];
      const restricted = effectiveCategory(app, allowedKeys) === 'restricted';
      const limit = config?.daily_limit_seconds ?? 10800;
      if (restricted && usedSeconds >= limit) {
        return { locked: true };
      }
      const session: ActiveSession = {
        appKey,
        appName: app.name,
        restricted,
        startedAt: Date.now(),
      };
      setActiveSession(session);
      return { locked: false };
    },
    [config, usedSeconds],
  );

  const verifyPin = useCallback(
    async (pin: string): Promise<boolean> => {
      const correct = config?.pin ?? '1234';
      const ok = pin === correct;
      if (ok) setPinned(true);
      return ok;
    },
    [config],
  );

  const updatePin = useCallback(async (newPin: string) => {
    await supabase.from('detox_config').update({ pin: newPin, updated_at: new Date().toISOString() }).eq('id', 1);
    setConfig((c) => (c ? { ...c, pin: newPin } : c));
  }, []);

  const updateDailyLimit = useCallback(async (seconds: number) => {
    await supabase
      .from('detox_config')
      .update({ daily_limit_seconds: seconds, updated_at: new Date().toISOString() })
      .eq('id', 1);
    setConfig((c) => (c ? { ...c, daily_limit_seconds: seconds } : c));
  }, []);

  const updateAllowedApps = useCallback(async (keys: string[]) => {
    await supabase
      .from('detox_config')
      .update({ allowed_apps: keys, updated_at: new Date().toISOString() })
      .eq('id', 1);
    setConfig((c) => (c ? { ...c, allowed_apps: keys } : c));
  }, []);

  const resetUsage = useCallback(async () => {
    await supabase
      .from('detox_daily_usage')
      .upsert({ date: todayKey(), used_seconds: 0, updated_at: new Date().toISOString() }, { onConflict: 'date' });
    setUsedSeconds(0);
  }, []);

  return {
    config,
    loading,
    error,
    usedSeconds,
    activeSession,
    pinned,
    refresh,
    openApp,
    closeActiveApp,
    verifyPin,
    updatePin,
    updateDailyLimit,
    updateAllowedApps,
    resetUsage,
  };
}
