export interface DetoxConfig {
  id: number;
  pin: string;
  daily_limit_seconds: number;
  allowed_apps: string[];
  updated_at: string;
}

export interface DetoxDailyUsage {
  date: string; // YYYY-MM-DD
  used_seconds: number;
  updated_at: string;
}

export interface DetoxSession {
  id: string;
  app_key: string;
  app_name: string;
  restricted: boolean;
  date: string;
  duration_seconds: number;
  started_at: string;
  ended_at: string | null;
}
